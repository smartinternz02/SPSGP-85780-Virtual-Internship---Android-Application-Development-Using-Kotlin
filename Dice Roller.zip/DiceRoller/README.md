Project: Dice Roller App
==================================

Starter code for the first independent project for [Android Basics in Kotlin](https://developer.android.com/courses/android-basics-kotlin/course)

![screenshot](https://telegra.ph/file/283864dee9530f94e6e01.png)

Note
----

- This Project is Completed by Me.
- Link to APK File is [Dice Roller App](https://github.com/noobshubham/diceroller/releases/download/v1.0/diceroller.apk)
